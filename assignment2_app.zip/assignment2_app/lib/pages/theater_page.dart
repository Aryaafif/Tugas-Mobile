import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class TheaterPage extends StatefulWidget {
  const TheaterPage({super.key});

  @override
  State<TheaterPage> createState() => _TheaterPageState();
}

class _TheaterPageState extends State<TheaterPage> {
  String _location = "Mendeteksi lokasi...";

  @override
  void initState() {
    super.initState();
    _getLocation();
  }

  Future<void> _getLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() => _location = "Layanan lokasi tidak aktif");
      return;
    }

    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      setState(() => _location = "Izin lokasi ditolak");
      return;
    }

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    setState(() {
      _location =
          "Latitude: ${position.latitude}, Longitude: ${position.longitude}";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("THEATER"),
        backgroundColor: Colors.blue[900],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Text("Lokasi Anda: $_location",
                style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 12),
            const ExpansionTile(title: Text("XI CINEMA")),
            const ExpansionTile(title: Text("PONDOK KELAPA 21")),
            const ExpansionTile(title: Text("CGV")),
            const ExpansionTile(title: Text("CINEPOLIS")),
            const ExpansionTile(title: Text("CP MALL")),
            const ExpansionTile(title: Text("HERMES")),
          ],
        ),
      ),
    );
  }
}
